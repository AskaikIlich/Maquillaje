<?php
// if ($_SERVER["REQUEST_METHOD"] == "POST") {
//     $usuario = $_POST['usuario'];
//     $contrasena = $_POST['contrasena'];

//     require_once 'nuevoU.php';

//     $usuarioObj = new Usuario();
//     if ($usuarioObj->login($usuario, $contrasena)) {
//         // Inicio de sesión exitoso
//         echo "Inicio de sesión exitoso. Bienvenido, $usuario!";
//         // Puedes redirigir al usuario a otra página aquí si lo deseas
//     } else {
//         // Inicio de sesión fallido
//         echo "Inicio de sesión fallido. Por favor, verifica tus credenciales.";
//     }
// }
?>
