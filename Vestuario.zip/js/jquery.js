//    function mostrar(id) {
//        if (id == "prestamo") {
//            $("#prestamo").show();
//            $("#lavanderia").hide();
//            $("#tintoreria").hide();
//        }

//        if (id == "lavanderia") {
//            $("#prestamo").hide();
//            $("#lavanderia").show();
//            $("#tintoreria").hide();
//        }

//        if (id == "tintoreria") {
//            $("#prestamo").hide();
//            $("#lavanderia").hide();
//            $("#tintoreria").show();
//        }
//    }
