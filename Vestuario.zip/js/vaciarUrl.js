setTimeout(() => {
    window.history.replaceState(null,null,window.location.pathname);            
}, 0);
   
   