<?php
require_once ('../clases/chambista.php');

$consulta = new chambista();
$imprime= $consulta->consultar();



?>