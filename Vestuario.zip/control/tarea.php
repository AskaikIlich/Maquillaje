<?php
require_once ('../clases/tarea.php');
$consultar = new Tarea();
$consulta= $consultar->consultar_select();






?>