<?php
require_once ('../clases/evaluacion.php');
$consultar = new Evaluacion();
$consulta= $consultar->consultar_select();






?>