<?php
require_once ('../clases/Status_tarea.php');
$consultar = new STATUS_TAREA();
$consulta= $consultar->consultar_select();






?>
