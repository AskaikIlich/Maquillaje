<?php
include_once("bdbd.php");
Conec::conectar();
?>